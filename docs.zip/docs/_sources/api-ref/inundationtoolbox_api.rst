Inundation toolbox
------------------

Arrival_times
^^^^^^^^^^^^^
.. autofunction:: inundation_toolbox.arrival_times

rising_speeds
^^^^^^^^^^^^^
.. autofunction:: inundation_toolbox.rising_speeds

height_of_mrs
^^^^^^^^^^^^^
.. autofunction:: inundation_toolbox.height_of_mrs





