HYDAMO Helper Functions
=======================

convert_to_dhydamo_data
-----------------------

.. autofunction:: hydamo_helpers.convert_to_dhydamo_data
