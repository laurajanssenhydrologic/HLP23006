To Dhydro Helper Functions
--------------------------
	
to_dhydro
^^^^^^^^^
.. autofunction:: to_dhydro_helpers.to_dhydro

write_dimr
^^^^^^^^^^
.. autofunction:: to_dhydro_helpers.write_dimr