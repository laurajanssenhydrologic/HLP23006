Hisreader
=========

Hisreader
---------
.. autoclass:: hisreader.HisResults
   :members: 
   
