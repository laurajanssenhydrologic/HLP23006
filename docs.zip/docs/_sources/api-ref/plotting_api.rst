Plotting
--------

raster_plot_with_context
^^^^^^^^^^^^^^^^^^^^^^^^
.. autofunction:: plotting.raster_plot_with_context







