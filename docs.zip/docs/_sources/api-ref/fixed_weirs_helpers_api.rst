Fixed Weirs Helper Functions
----------------------------

create_dambreak_data
^^^^^^^^^^^^^^^^^^^^
.. autofunction:: fixedweirs_helpers.create_dambreak_data
   

create_fixed_weir_data
^^^^^^^^^^^^^^^^^^^^^^
.. autofunction:: fixedweirs_helpers.create_fixed_weir_data
