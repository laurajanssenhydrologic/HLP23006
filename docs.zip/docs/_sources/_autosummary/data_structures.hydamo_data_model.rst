data\_structures.hydamo\_data\_model
====================================

.. automodule:: data_structures.hydamo_data_model

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      BasicSchema
      BrugSchema
      DuikerSchema
      GPDBasicShema
      GemaalSchema
      HydamoDataModel
      Hydroobject_normgpSchema
      KunstwerkopeningSchema
      NormgeparamprofielwaardeSchema
      PDBasicShema
      PompSchema
      ProfielgroepSchema
      ProfiellijnSchema
      ProfielpuntSchema
      RegelmiddelSchema
      RuwheidsprofielSchema
      SturingSchema
      StuwSchema
      WaterloopSchema
   
   

   
   
   



