data\_structures.dhydamo\_data\_model\_old
==========================================

.. automodule:: data_structures.dhydamo_data_model_old

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      BasicSchema
      BrugSchema
      DHydamoDataModel
      DuikerSchema
      GPDBasicShema
      GemaalSchema
      Hydroobject_normgpSchema
      KunstwerkopeningSchema
      NormgeparamprofielwaardeSchema
      PDBasicShema
      PompSchema
      ProfielgroepSchema
      ProfiellijnSchema
      ProfielpuntSchema
      RegelmiddelSchema
      RuwheidsprofielSchema
      SturingSchema
      StuwSchema
      WaterloopSchema
   
   

   
   
   



