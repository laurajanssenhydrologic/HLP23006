data\_structures.roi\_data\_model
=================================

.. automodule:: data_structures.roi_data_model

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      BrugSchema
      DuikerSchema
      GemaalSchema
      Hydroobject_normgpSchema
      KunstwerkopeningSchema
      NormgeparamprofielwaardeSchema
      PompSchema
      ProfielgroepSchema
      ProfiellijnSchema
      ProfielpuntSchema
      ROIDataModel
      RegelmiddelSchema
      RuwheidsprofielSchema
      SturingSchema
      StuwSchema
      WaterloopSchema
   
   

   
   
   



