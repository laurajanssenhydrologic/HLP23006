data\_structures.hydamo\_helpers
================================

.. automodule:: data_structures.hydamo_helpers

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      check_and_fix_duplicate_code
      check_column_is_numerical
      check_is_not_na_number
      check_roughness
      convert_to_dhydamo_data
      load_geo_file
      map_columns
      merge_to_ddm
      merge_to_dm
   
   

   
   
   

   
   
   



