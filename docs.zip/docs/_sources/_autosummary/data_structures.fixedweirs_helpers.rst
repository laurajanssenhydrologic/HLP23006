data\_structures.fixedweirs\_helpers
====================================

.. automodule:: data_structures.fixedweirs_helpers

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      create_dambreak_data
      create_fixed_weir_data
      create_underpass_data
      merge_to_fddm
   
   

   
   
   

   
   
   



